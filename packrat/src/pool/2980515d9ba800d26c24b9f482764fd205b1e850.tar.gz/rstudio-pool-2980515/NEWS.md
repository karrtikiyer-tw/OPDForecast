pool 0.1.0.9000
================

## Full changelog

### Breaking changes
* Fix [#39](https://github.com/rstudio/pool/issues/39): Moved `dplyr` support in `pool` from `dplyr` 0.5.0 to `dplyr` 0.7.0, which includes a lot of breaking changes including the addition of a brand new package called `dbplyr`. ([#42](https://github.com/rstudio/pool/pull/42))

### New features

### Minor new features and improvements

### Bug fixes

### Library updates
* Roxygen 5.0.1 to 6.0.1 (commit (#9952000)[https://github.com/rstudio/pool/commit/99520001a65dd51a4f5eaaacad4bfbec696cc0f1])

pool 0.1.0
===========

* Initial release!
